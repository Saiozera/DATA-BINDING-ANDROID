"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function CalculatorPage() {
  // Basic calculator state
  const [display, setDisplay] = useState("0")
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  // Ohm's law calculator state
  const [voltage, setVoltage] = useState("")
  const [current, setCurrent] = useState("")
  const [resistance, setResistance] = useState("")
  const [ohmResult, setOhmResult] = useState("")

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === "0" ? num : display + num)
    }
  }

  const inputOperation = (nextOperation: string) => {
    const inputValue = Number.parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case "+":
        return firstValue + secondValue
      case "-":
        return firstValue - secondValue
      case "×":
        return firstValue * secondValue
      case "÷":
        return firstValue / secondValue
      default:
        return secondValue
    }
  }

  const performCalculation = () => {
    const inputValue = Number.parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation)
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForOperand(true)
    }
  }

  const clearCalculator = () => {
    setDisplay("0")
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  const calculateOhmsLaw = () => {
    const v = Number.parseFloat(voltage)
    const i = Number.parseFloat(current)
    const r = Number.parseFloat(resistance)

    // Calculate missing value based on V = I × R
    if (!isNaN(v) && !isNaN(i) && isNaN(r)) {
      // Calculate resistance: R = V / I
      const result = v / i
      setResistance(result.toFixed(2))
      setOhmResult(`Resistência: ${result.toFixed(2)} Ω`)
    } else if (!isNaN(v) && isNaN(i) && !isNaN(r)) {
      // Calculate current: I = V / R
      const result = v / r
      setCurrent(result.toFixed(2))
      setOhmResult(`Corrente: ${result.toFixed(2)} A`)
    } else if (isNaN(v) && !isNaN(i) && !isNaN(r)) {
      // Calculate voltage: V = I × R
      const result = i * r
      setVoltage(result.toFixed(2))
      setOhmResult(`Tensão: ${result.toFixed(2)} V`)
    } else {
      setOhmResult("Por favor, insira exatamente dois valores para calcular o terceiro")
    }
  }

  const clearOhmsLaw = () => {
    setVoltage("")
    setCurrent("")
    setResistance("")
    setOhmResult("")
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="mx-auto max-w-md space-y-6">
        {/* Updated title to TP1 and translated to Portuguese */}
        <h1 className="text-center text-2xl font-bold text-foreground">TP1 - Calculadora & Lei de Ohm</h1>

        {/* Basic Calculator */}
        <Card>
          <CardHeader>
            {/* Translated card title to Portuguese */}
            <CardTitle>Calculadora Básica</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Display */}
            <div className="rounded-lg bg-muted p-4 text-right">
              <div className="text-2xl font-mono text-foreground">{display}</div>
            </div>

            {/* Calculator Buttons */}
            <div className="grid grid-cols-4 gap-2">
              {/* Translated Clear button to Portuguese */}
              <Button variant="outline" onClick={clearCalculator} className="col-span-2 bg-transparent">
                Limpar
              </Button>
              <Button variant="outline" onClick={() => inputOperation("÷")}>
                ÷
              </Button>
              <Button variant="outline" onClick={() => inputOperation("×")}>
                ×
              </Button>

              <Button variant="outline" onClick={() => inputNumber("7")}>
                7
              </Button>
              <Button variant="outline" onClick={() => inputNumber("8")}>
                8
              </Button>
              <Button variant="outline" onClick={() => inputNumber("9")}>
                9
              </Button>
              <Button variant="outline" onClick={() => inputOperation("-")}>
                -
              </Button>

              <Button variant="outline" onClick={() => inputNumber("4")}>
                4
              </Button>
              <Button variant="outline" onClick={() => inputNumber("5")}>
                5
              </Button>
              <Button variant="outline" onClick={() => inputNumber("6")}>
                6
              </Button>
              <Button variant="outline" onClick={() => inputOperation("+")}>
                +
              </Button>

              <Button variant="outline" onClick={() => inputNumber("1")}>
                1
              </Button>
              <Button variant="outline" onClick={() => inputNumber("2")}>
                2
              </Button>
              <Button variant="outline" onClick={() => inputNumber("3")}>
                3
              </Button>
              <Button
                variant="default"
                onClick={performCalculation}
                className="row-span-2 bg-accent hover:bg-accent/90"
              >
                =
              </Button>

              <Button variant="outline" onClick={() => inputNumber("0")} className="col-span-2">
                0
              </Button>
              <Button variant="outline" onClick={() => inputNumber(".")}>
                .
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Ohm's Law Calculator */}
        <Card>
          <CardHeader>
            {/* Translated card title and description to Portuguese */}
            <CardTitle>Calculadora da Lei de Ohm</CardTitle>
            <p className="text-sm text-muted-foreground">V = I × R (Insira dois valores para calcular o terceiro)</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                {/* Translated voltage label and placeholder to Portuguese */}
                <Label htmlFor="voltage">Tensão (V)</Label>
                <Input
                  id="voltage"
                  type="number"
                  placeholder="Digite a tensão em volts"
                  value={voltage}
                  onChange={(e) => setVoltage(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                {/* Translated current label and placeholder to Portuguese */}
                <Label htmlFor="current">Corrente (I)</Label>
                <Input
                  id="current"
                  type="number"
                  placeholder="Digite a corrente em ampères"
                  value={current}
                  onChange={(e) => setCurrent(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                {/* Translated resistance label and placeholder to Portuguese */}
                <Label htmlFor="resistance">Resistência (R)</Label>
                <Input
                  id="resistance"
                  type="number"
                  placeholder="Digite a resistência em ohms"
                  value={resistance}
                  onChange={(e) => setResistance(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2">
              {/* Translated Calculate and Clear buttons to Portuguese */}
              <Button onClick={calculateOhmsLaw} className="flex-1">
                Calcular
              </Button>
              <Button variant="outline" onClick={clearOhmsLaw}>
                Limpar
              </Button>
            </div>

            {ohmResult && (
              <div className="rounded-lg bg-muted p-4">
                <div className="text-lg font-semibold text-foreground">{ohmResult}</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
